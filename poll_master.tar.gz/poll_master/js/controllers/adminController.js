/**
 * Created by karthik on 12/4/17.
 */
pollApp.controller('adminController',['$scope', function($scope){

}]);
